/* stdafx.h
 * Standard included files and definitions
 * For use with MechMania IV
 * 4/29/98 by Misha Voloshin
*/

#ifndef _STDAFX_H_DIFHSDLIFHSLDFHLSEFGLSEFG
#define _STDAFX_H_DIFHSDLIFHSLDFHLSEFGLSEFG

#include <stdlib.h>
#include <stdio.h>
#include <iostream.h>

#include <math.h>
#include <string.h>

#include <sys/types.h>
#include <time.h>

#ifndef UINT
#define UINT unsigned
#endif // !UINT

#ifndef BOOL
#define BOOL unsigned char
#endif // !BOOL

#ifndef TRUE
#define TRUE 1
#endif // !TRUE

#ifndef FALSE
#define FALSE 0
#endif // !FALSE

#endif // !_STDAFX_H_DIFHSDLIFHSLDFHLSEFGLSEFG
